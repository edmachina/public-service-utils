import logging
import os


class EnvVariable:
    """Convenient class for handling environment variables and their validation.

    This class can be used to read and validate environment variables, assign default values, cast to specified data
    types and to validate the content.

    Attributes:
        value: A read only attribute containing the assigned value of teh environment variable


    """
    def __init__(self, name, dtype, default=None):
        """Inits EnvVariable with the specified name, dtype and default value."""
        try:
            self._value = os.environ.get(name, default)
            self._value = dtype(self._value)
        except:
            self._value = None
        self.name = name
        self._dtype = dtype
        self._default = default

    @property
    def value(self):
        return self._value

    def validate(self):
        """Validates that the environment variable can be found."""
        val = os.environ.get(self.name, self._default)
        if val is None:
            logging.error("The %s environment variable is not declared" % self.name)
            return False
        try:
            self._dtype(val)
        except:
            logging.error("Invalid environment variable data type for %s" % self.name)
            return False
        return True


