from flask_restx.utils import unpack, merge
from flask_restx.model import Model
from functools import wraps
from marshmallow import Schema
from marshmallow_jsonschema import JSONSchema
from webargs.flaskparser import parser
from webargs.multidictproxy import MultiDictProxy


@parser.location_loader("all_locations_json")
def load_data_json(request, schema):
    new_data = request.args.copy()
    new_data.update(request.view_args)
    new_data.update(request.headers)
    new_data.update(request.json)
    return MultiDictProxy(new_data, schema)


@parser.location_loader("all_locations_files")
def load_data_files(request, schema):
    new_data = request.args.copy()
    new_data.update(request.view_args)
    new_data.update(request.headers)
    new_data.update(request.form)
    new_data.update(request.files)
    return MultiDictProxy(new_data, schema)


def doc_response(api, schema, code=200, description=None, **kwargs):
    if isinstance(schema, Schema):
        marshmallow_to_jsonschema = JSONSchema()
        json_schema = marshmallow_to_jsonschema.dump(schema)["definitions"]
        key = next(iter(json_schema.keys()))
        model = api.schema_model(name=key, schema=json_schema[key])
    else:
        model = None

    def decorator(func):
        if isinstance(model, Model):
            doc = {
                "responses": {str(code): (description, model, kwargs)},
                "__mask__": kwargs.get(
                    "mask", True
                ),  # Mask values can't be determined outside app context
            }
            func.__apidoc__ = merge(getattr(func, "__apidoc__", {}), doc)
        else:
            func = api.response(code, description)(func)
        return func
    return decorator


def parse_args(api, schema, location="json"):
    if location == "json":
        marshmallow_to_jsonschema = JSONSchema()
        json_schema = marshmallow_to_jsonschema.dump(schema)["definitions"]
        key = next(iter(json_schema.keys()))
        model = api.schema_model(name=key, schema=json_schema[key])

    def decorator(func):
        if location == "json":
            func = api.expect(model, validate=False)(func)

        @wraps(func)
        def wrapper(*args, **kwargs):
            nonlocal func
            func = parser.use_args(schema, location=location, unknown=None)(func)
            result = func(*args, **kwargs)
            return result
        return wrapper
    return decorator


def marshall_output(api, schema, code=200, description=None, **kwargs):
    marshmallow_to_jsonschema = JSONSchema()
    json_schema = marshmallow_to_jsonschema.dump(schema)["definitions"]
    key = next(iter(json_schema.keys()))
    model = api.schema_model(name=key, schema=json_schema[key])

    def decorator(func):
        doc = {
            "responses": {str(code): (description, model, kwargs)},
            "__mask__": kwargs.get(
                "mask", True
            ),  # Mask values can't be determined outside app context
        }
        func.__apidoc__ = merge(getattr(func, "__apidoc__", {}), doc)

        @wraps(func)
        def wrapper(*args, **kwargs2):
            nonlocal func
            nonlocal schema
            resp = func(*args, **kwargs2)
            if isinstance(resp, tuple):
                data, current_code, headers = unpack(resp)
                return (
                    schema.dump(data),
                    current_code,
                    headers,
                )
            else:
                return schema.dump(resp)
        return wrapper
    return decorator
