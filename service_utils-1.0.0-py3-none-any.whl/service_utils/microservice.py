from flask_restx.utils import unpack, merge
from flask_restx.model import Model
from functools import wraps
from marshmallow import Schema, fields, EXCLUDE
from marshmallow_jsonschema import JSONSchema
from webargs.flaskparser import parser
from webargs.multidictproxy import MultiDictProxy


def create_multi_location_schema(current_json=None, current_querystring=None, current_headers=None, current_form=None,
                                current_view_args=None, current_files=None):

    class MultiLocationSchema(Schema):
        json_schema = current_json
        querystring_schema = current_querystring
        headers_schema = current_headers
        form_schema = current_form
        view_args_schema = current_view_args
        files_schema = current_files

        if current_json is not None:
            if current_json.many:
                json = fields.List(fields.Nested(type(current_json)))
            else:
                json = fields.Nested(type(current_json))
        if current_querystring is not None:
            querystring = fields.Nested(type(current_querystring))
        if current_headers is not None:
            headers = fields.Nested(type(current_headers))
        if current_form is not None:
            form = fields.Nested(type(current_form))
        if current_view_args is not None:
            view_args = fields.Nested(type(current_view_args))
        if current_files is not None:
            files = fields.Nested(type(current_files))

        class Meta:
            unknown = EXCLUDE

    return MultiLocationSchema


@parser.location_loader('load_multiple_locations')
def load_multiple_locations(request, schema):
    data = dict()
    if schema.json_schema is not None:
        data['json'] = parser.load_json(request, schema.json_schema)
    if schema.querystring_schema is not None:
        data['query'] = parser.load_querystring(request, schema.querystring_schema)
    if schema.headers_schema is not None:
        data['headers'] = parser.load_headers(request, schema.headers_schema)
    if schema.form_schema is not None:
        data["form"] = parser.load_form(request, schema.form_schema)
    if schema.view_args_schema is not None:
        data["view_args"] = parser.load_view_args(request, schema.view_args_schema)
    if schema.files_schema is not None:
        data["files"] = parser.load_files(request, schema.files_schema)

    return MultiDictProxy(data, schema)


def doc_response(api, schema, code=200, description=None, **kwargs):
    if isinstance(schema, Schema):
        marshmallow_to_jsonschema = JSONSchema()
        json_schema = marshmallow_to_jsonschema.dump(schema)["definitions"]
        key = next(iter(json_schema.keys()))
        model = api.schema_model(name=key, schema=json_schema[key])
    else:
        model = None

    def decorator(func):
        if isinstance(model, Model):
            doc = {
                "responses": {str(code): (description, model, kwargs)},
                "__mask__": kwargs.get(
                    "mask", True
                ),  # Mask values can't be determined outside app context
            }
            func.__apidoc__ = merge(getattr(func, "__apidoc__", {}), doc)
        else:
            func = api.response(code, description)(func)
        return func
    return decorator


def parse_args(api, json=None, querystring=None, headers=None, form=None, view_args=None, files=None, **kwargs):
    multi_location_schema = create_multi_location_schema(current_json=json, current_querystring=querystring,
                                                         current_headers=headers, current_form=form,
                                                         current_view_args=view_args, current_files=files)

    schema = multi_location_schema()

    if json is not None:
        # json swagger documentation
        marshmallow_to_jsonschema = JSONSchema()
        json_schema = marshmallow_to_jsonschema.dump(json)["definitions"]
        key = next(iter(json_schema.keys()))
        model = api.schema_model(name=key, schema=json_schema[key])

    if querystring is not None:
        # querystring swagger documentation
        pass

    if headers is not None:
        # headers swagger documentation
        pass

    if form is not None:
        # form swagger documentation
        pass

    if view_args is not None:
        # view_args swagger documentation
        pass

    if files is not None:
        # files swagger documentation
        pass

    def decorator(func):
        if json is not None:
            func = api.expect(model, validate=False)(func)

        if querystring is not None:
            # querystring swagger documentation
            pass

        if headers is not None:
            # headers swagger documentation
            pass

        if form is not None:
            # form swagger documentation
            pass

        if view_args is not None:
            # view_args swagger documentation
            pass

        if files is not None:
            # files swagger documentation
            pass

        @wraps(func)
        def wrapper(*args, **kwargs):
            nonlocal func
            func = parser.use_args(schema, location='load_multiple_locations', unknown=None)(func)
            result = func(*args, **kwargs)
            return result
        return wrapper
    return decorator


def marshall_output(api, schema, code=200, description=None, **kwargs):
    marshmallow_to_jsonschema = JSONSchema()
    json_schema = marshmallow_to_jsonschema.dump(schema)["definitions"]
    key = next(iter(json_schema.keys()))
    model = api.schema_model(name=key, schema=json_schema[key])

    def decorator(func):
        doc = {
            "responses": {str(code): (description, model, kwargs)},
            "__mask__": kwargs.get(
                "mask", True
            ),  # Mask values can't be determined outside app context
        }
        func.__apidoc__ = merge(getattr(func, "__apidoc__", {}), doc)

        @wraps(func)
        def wrapper(*args, **kwargs2):
            nonlocal func
            nonlocal schema
            resp = func(*args, **kwargs2)
            if isinstance(resp, tuple):
                data, current_code, headers = unpack(resp)
                return (
                    schema.dump(data),
                    current_code,
                    headers,
                )
            else:
                return schema.dump(resp)
        return wrapper
    return decorator
