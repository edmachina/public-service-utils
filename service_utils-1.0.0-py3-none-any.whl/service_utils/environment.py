import logging
import os


class EnvVariable:
    """Convenient class for handling environment variables and their validation.

    This class can be used to read and validate environment variables, assign default values, cast to specified data
    types and to validate the content.

    Properties:
        name: The environment variable name
        value: A read only attribute containing the assigned value of teh environment variable
        dtype: Data type or casting function

    Typical usage example:

    my_env_var = EnvVariable("A_VARIABLE_NAME", str)
    if not my_env_var.validate():
        raise EnvironmentError("A_VARIABLE_NAME environment variable noty found")

    print(f"my_env_var value: {my_env_var.value}")

    """
    def __init__(self, name, dtype, default=None):
        """Inits EnvVariable with the specified name, dtype and default value."""
        # noinspection PyBroadException
        try:
            self._value = os.environ.get(name, default)
            if self.value is not None:
                self._value = dtype(self._value)
        except:
            self._value = None
        self._name = name
        self._dtype = dtype
        self._default = default

    @property
    def value(self):
        return self._value

    @property
    def name(self):
        return self._name

    @property
    def dtype(self):
        return self._dtype

    def validate(self):
        """Validates that the environment variable can be found."""
        val = os.environ.get(self._name, self._default)
        if val is None:
            logging.error("The %s environment variable is not declared" % self.name)
            return False
        # noinspection PyBroadException
        try:
            self._dtype(val)
        except:
            logging.error("Invalid environment variable data type for %s" % self.name)
            return False
        return True
