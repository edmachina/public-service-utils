import urllib.parse

from pymongo import MongoClient


class DbClient:
    """

    """
    def __init__(self, db_user, db_password, db_url, db_name):
        self._db_user = db_user
        self._db_password = db_password
        self._db_url = db_url
        self._db_name = db_name

    @property
    def db_user(self):
        return self._db_user

    @property
    def db_password(self):
        return self._db_password

    @property
    def db_url(self):
        return self._db_url

    @property
    def db_name(self):
        return self._db_name

    def get_connection(self):
        user = urllib.parse.quote_plus(self._db_user)
        passwd = urllib.parse.quote_plus(self._db_password)
        uri = 'mongodb://%s:%s@%s/?authMechanism=SCRAM-SHA-1' % (
            user,
            passwd,
            self._db_url
        )
        db_client = MongoClient(uri)
        return db_client[self._db_name]

    def get_collection(self, name):
        conn = self.get_connection()
        return conn.db[name]
