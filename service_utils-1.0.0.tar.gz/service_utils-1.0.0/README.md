# Utils for EdMachina micro-services

## Build instructions

1. ```pip3 install build```
2. ```python3 -m build --wheel```